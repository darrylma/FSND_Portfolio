Contents
-------------------------------------

1. fresh_tomatoes.html - used to launch webpage
2. fresh_tomatoes.py - contains html, css and python script to load movie details
3. media.py - defines Movie class
4. entertainment_center.py - defines instances of Movie class


Quick Start
-------------------------------------
1. Ensure you have internet connection
2. Go to Movie_Webpage folder
3. Double click on fresh_tomatoes.html file
4. Click on movie's poster to watch corresponding trailer