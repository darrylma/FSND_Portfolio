1. Enter psql
2. Run following script 'CREATE DATABASE tournament;'
3. Connect psql to your new tournament database
4. Use the command \i tournament.sql to create tables and views
5. Ignore first 5 errors that mention views/tables do not exist as code is
   attempting to drop tables that do not exist
6. Run test script (e.g. python tournament_test.py)
